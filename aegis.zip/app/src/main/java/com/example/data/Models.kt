package com.example.data

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class UserProfile(
    val name: String = "",
    val language: String = "",
    val homeCountry: String = "",
    val homeCity: String = "",
    val constraints: List<String> = emptyList(),
    val passport: String? = null,
    val emergencyContact: String? = null,
    val bloodType: String? = null
)

@JsonClass(generateAdapter = true)
data class CrisisEvent(
    val type: String = "",
    val title: String = "",
    val location: String = "",
    val description: String = "",
    val severity: String = ""
)

@JsonClass(generateAdapter = true)
data class EnvironmentEntry(
    val id: String = "",
    val name: String = "",
    val type: String = "",
    val coordinates: String = "",
    val distance: String = ""
)

@JsonClass(generateAdapter = true)
data class Shelter(
    val id: String = "",
    val name: String = "",
    val address: String = "",
    val capacity: Int = 0,
    val stepFree: Boolean = false,
    val distance: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0
)

@JsonClass(generateAdapter = true)
data class LiveDelta(
    val shelters: List<Shelter> = emptyList(),
    val lastUpdated: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class EmbassyInfo(
    val name: String = "",
    val url: String = "",
    val phone: String = "",
    val address: String = ""
)

@JsonClass(generateAdapter = true)
data class CountryContext(
    val laws: List<String> = emptyList(),
    val protocols: List<String> = emptyList(),
    val emergencyNumbers: Map<String, String> = emptyMap(),
    val embassy: EmbassyInfo? = null
)

@JsonClass(generateAdapter = true)
data class Alert(
    val source: String = "",
    val level: String = "",
    val title: String = "",
    val description: String = "",
    val time: String = ""
)

@JsonClass(generateAdapter = true)
data class Guidance(
    val text: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val needsTap: Boolean = false
)

@JsonClass(generateAdapter = true)
data class NetworkState(
    val online: Boolean = true,
    val environment: String = ""
)

@JsonClass(generateAdapter = true)
data class SituationObject(
    val sessionId: String = "",
    val interactionChainId: String? = null,
    val scoutEnvironmentId: String? = null,
    val user: UserProfile = UserProfile(),
    val event: CrisisEvent = CrisisEvent(),
    val environment: List<EnvironmentEntry> = emptyList(),
    val liveDelta: LiveDelta = LiveDelta(),
    val countryContext: CountryContext? = null,
    val activeAlerts: List<Alert> = emptyList(),
    val guidance: Guidance = Guidance(),
    val network: NetworkState = NetworkState()
)
